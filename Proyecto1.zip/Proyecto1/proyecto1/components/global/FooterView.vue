<template>
  <div class="row"  style="margin-top: 15px">
    <button disabled="disabled" class="twelve columns button-primary">
      Copyright (c) 2021 - María Laura Alfaro Espinoza - Kevin Campos Vargas
    </button>
  </div>
</template>