---
id: pelicula_1
name: Madagascar
directorId: director_1
estudioId: estudio_1
gender: Comedia
duration: 1 hora y 30 min 
year: 2005
image: peliculas/pelicula_1.jpg
---

La historia empieza con una cebra (Marty), corriendo tranquilamente por la jungla, cuando de repente aparece un león (Alex) que la persigue. 
Cuando Marty deja de soñar (porque lo despierta Alex) ve a Alex festejando su cumpleaños y le da de regalo una esfera de vidrio en la que aparece 
una figurita del propio Alex. De pronto el reloj toca las 9:00 y los niños entran al zoo. Alex, apresurado, despierta a una jirafa (Melman) y a una 
hipopótamo (Gloria). 