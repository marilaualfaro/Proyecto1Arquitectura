---
id: pelicula_11
name: La Historia de una Abeja
directorId: director_5
estudioId: estudio_2
gender: Comedia
duration: 90 minutos 
year: 2007
image: peliculas/pelicula_11.jpg
---

Una joven abeja llamado Barry B. Benson (Jerry Seinfeld) se graduó recientemente de la universidad y está a punto de ingresar 
a la fuerza de trabajo de la colmena Industrias Honex (Mielex en español) junto con su mejor amigo Adam Flayman (Matthew Broderick). 
Inicialmente, Barry está entusiasmado por unirse a la fuerza de trabajo, pero surge su actitud valiente e inconformista al descubrir 
que su elección de trabajo nunca cambiará una vez elegida. Más tarde, las dos abejas se topan con un grupo de polenjocks (polinesios en Hispanoamérica), 
las abejas que recogen polen de las flores fuera de la colmena. Los Jocks ofrecen llevar a Barry fuera de la colmena a un parche de flores, y él acepta. 
Durante su primera expedición de recolección de polen en la ciudad de Nueva York, Barry se pierde bajo la lluvia y termina en el balcón de una florista 
humana llamada Vanessa (Renée Zellweger). Al darse cuenta de Barry, el novio de Vanessa, Ken (Patrick Warburton), intenta aplastarlo, pero Vanessa atrapa 
suavemente y suelta a Barry fuera de la ventana, salvándole la vida.
