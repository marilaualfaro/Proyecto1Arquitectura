---
id: pelicula_9
name: Megamind
directorId: director_5
estudioId: estudio_1
gender: Infantil
duration: 90 minutos
year: 2010
image: peliculas/pelicula_9.jpg
---

Megamente (Will Ferrell) es un extraterrestre con una enorme cabeza que llega a la Tierra con apenas ocho días de nacido, 
ya que sus padres lo evacuaron a causa de la destrucción de su planeta por un agujero negro. La misma situación ocurre con 
Metro Man (Brad Pitt), otro extraterrestre con forma humana. Su viaje por el espacio finaliza en la Tierra, donde Megamente 
iba a caer en una casa de una pareja millonaria pero Metro Man lo desvía hacia la cárcel. Así, se hace amigo de los prisioneros, 
quienes le enseñan que el bien es malo y lo malo es bueno. Después de un tiempo, Megamente causa una fuga en la prisión pero es 
detenido por el jefe de policía, quien lo encarcela y lo lleva a la escuela. Al darse cuenta de que su talento es la causa de problemas, 
y celoso de toda la atención que el joven Metro Man recibe, Megamente se convierte en un supervillano junto con su pez Minion 
(Servil en Hispanoamérica, Esbirro en España) (David Cross) para competir contra Metro Man.