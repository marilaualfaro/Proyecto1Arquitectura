---
id: pelicula_5
name: Un Jefe en Pañales
directorId: director_1
estudioId: estudio_2
gender: Comedia
duration: 98 minutos 
year: 2017
image: peliculas/pelicula_5.jpg
---

Un hombre llamado Tim Templeton cuenta una historia sobre su yo imaginativo de siete años y sus padres, Ted y Janice. 
Un día, Tim se sorprende cuando un bebé vestido con un traje de negocios llega a su casa en un taxi, y Ted y Janice se 
refieren a él como el hermano pequeño de Tim. Tim envidia la atención que recibe el bebé de un día y sospecha por la ropa 
del bebé y el comportamiento extraño que exhibe con Tim, pero sus padres no se dan cuenta.

Pronto, Tim se entera de que el bebé puede hablar como un adulto y se presenta como "El Jefe". Al ver la oportunidad de 
deshacerse de él, Tim decide usar un cinta de cassette para grabar una conversación entre Boss Baby y otros niños pequeños 
que están en la casa de Tim para una reunión, con el pretexto de una cita para jugar en los ojos de los padres. En este encuentro, 
Boss Baby explica que los cachorros han estado recibiendo más cariño que los bebés y está en busca de un nuevo archivo que contenga 
evidencias de un nuevo cachorro de Puppy Co., empresa que lanza nuevos productos para perros, que pretende lanzar. Antes de que puedan 
terminar, atrapan a Tim espiándolos. Se produce una persecución y Boss Baby amenaza con destrozar el peluche favorito de Tim, Lam-Lam. 
Tim intenta tirar a Boss Baby por una ventana, pero es atrapado por sus padres, y accidentalmente tira la cinta de cassette fuera de la 
casa antes de que sea destruida por un automóvil que pasa. Sin pruebas que lo respalden, los padres de Tim lo castigan hasta que se hace 
amigo de Boss Baby.