---
id: pelicula_7
name: Ratatouille
directorId: director_3
estudioId: estudio_3
gender: Comedia
duration: 110 minutos
year: 2007
image: peliculas/pelicula_7.jpg
---

Remy es una rata que vive en el ático de una casa francesa con su hermano Emile y una colonia liderada por su padre Django. 
Dotado con un agudo sentido del olfato y gusto, Remy aspira a convertirse en un chef gourmet, inspirado por el reconocido y 
recientemente fallecido chef Auguste Gusteau (el cual veía en la televisión de la casa en la cual estaba instalada la colonia), 
pero en lugar de eso, su habilidad es utilizada para detectar el veneno en la comida, lo cual no lo hace nada feliz. Un día, Remy 
y Emile son vistos por la anciana que habita en la casa y ella, en su intento por capturarlos, descubre a la colonia de ratas, por lo 
que estas huyen a las alcantarillas; Remy se separa de ellas por recuperar un libro de cocina escrito por Gusteau, titulado 
"Cualquiera puede cocinar", por lo que se pierde, yéndose por la intersección equivocada de la alcantarilla (la izquierda, mientras que 
su colonia se fue por la de la derecha).

Una vez en París, y animado por el espíritu de Gusteau, Remy halla la forma de escalar hasta el techo transparente de la cocina del restaurante 
Gusteau's para mirar a los cocineros en acción. 