---
id: pelicula_6
name: Las aventuras de Peabody y Sherman
directorId: director_2
estudioId: estudio_3
gender: Animación
duration: 92 min.
year: 2014
image: peliculas/pelicula_6.jpg
---

Mr. Peabody es solo un perro que habla y es el ser más inteligente del mundo. De cachorro, fue rechazado por todos los potenciales propietarios, 
lo que lo llevó a dedicar su vida a la ciencia, los deportes, y los descubrimientos tecnológicos. Un día, Peabody se encuentra un niño huérfano 
y lo adopta legalmente bajo el nombre de Sherman. Él le da clases particulares a Sherman a través de una serie de aventuras a lo largo de la historia 
con el uso de la WABAC (en español el Vueltatrás), una máquina del tiempo y su mayor invento. Después de escapar de la Revolución Francesa, Sherman 
comienza su primer día de clases en la escuela Susan B. Anthony, y cae en conflicto con su compañera Penny Peterson, a quien inocentemente superó en la 
clase de historia con su conocimiento de primera mano de George Washington. Penny intimida y humilla a Sherman, insultándolo y llamándolo un "perro" por 
haber sido criado por uno, le roba su silbato para perros, y además lo ataca físicamente haciéndole una llave a la cabeza, lo cual provoca que Sherman la 
muerda en el brazo izquierdo fuera de pantalla. Entonces, el director Purdy llama a Mr. Peabody para hablar sobre el asunto, pero se enfrenta a Ms. Grunion, 
una intolerante trabajadora social que amenaza con quitarle a Peabody la custodia de Sherman si en una inspección próxima considera a Sherman cómo no apto 
para él.