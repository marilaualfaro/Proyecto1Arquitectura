---
id: pelicula_3
name: Los Increíbles
directorId: director_3
estudioId: estudio_3
gender: Comedia
duration: 2 horas
year: 2010
image: peliculas/pelicula_3.jpg
---

Alfred Vaino Aho (born August 9, 1941) is a Canadian computer scientist best known for his work on programming languages, compilers, and related algorithms, and his textbooks on the art and science of computer programming.

Aho was elected into the National Academy of Engineering in 1999 for his contributions to the fields of algorithms and programming tools.

He and his long-time collaborator Jeffrey Ullman are the recipients of the 2020 Turing Award, generally recognized as the highest distinction in computer science