---
id: pelicula_12
name: Oliver y su Pandilla
directorId: director_6
estudioId: estudio_3
gender: Animación
duration: 74 minutos
year: 1988
image: peliculas/pelicula_12.jpg
---

En la Quinta Avenida, un gatito huérfano llamado Oliver queda abandonado después de que sus compañeros son adoptados por los transeúntes. 
Mientras deambula por las calles en busca de alguien que lo adopte, Oliver se encuentra con un mestizo relajado llamado Dodger, que ayuda 
al gatito a robar comida de un vendedor de perros calientes. Dodger luego huye de la escena sin compartir su generosidad con Oliver. 
Oliver sigue a Dodger por todas las calles hasta que finalmente llega a una barcaza, donde Dodger comparte su comida con una pandilla de 
compañeros callejeros: el chihuahua Tito, el simpático gran danés Einstein, Rita la Saluki, y Francis el bulldog. Oliver se cuela adentro 
y es descubierto por los perros. Después de un momento de confusión, es recibido con una cálida bienvenida. El dueño de la barcaza, un 
carterista llamado Fagin, está en deuda con Sykes, un nefasto agente de astilleros y prestamista acompañado por sus Dobermans, Roscoe y DeSoto. 
Sykes le da a Fagin un ultimátum de devolver el dinero que había pedido prestado dentro de los tres días bajo la amenaza de violencia inminente.