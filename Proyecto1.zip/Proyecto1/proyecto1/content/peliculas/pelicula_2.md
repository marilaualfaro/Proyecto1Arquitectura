---
id: pelicula_2
name: Rey León
directorId: director_2
estudioId: estudio_2
gender: Comedia
duration: 1 hora y 40 min 
year: 2008
image: peliculas/pelicula_2.jpg
---

Andrew Stuart Tanenbaum (born March 16, 1944), sometimes referred to by the handle ast,[6] is an American-Dutch computer scientist and professor emeritus of computer science at the Vrije Universiteit Amsterdam in the Netherlands.

He is best known as the author of MINIX, a free Unix-like operating system for teaching purposes, and for his computer science textbooks, regarded as standard texts in the field. He regards his teaching job as his most important work. Since 2004 he has operated Electoral-vote.com, a website dedicated to analysis of polling data in federal elections in the United States.