---
id: pelicula_10
name: Aladdín
directorId: director_6
estudioId: estudio_3
gender: Aventura
duration: 90 minutos 
year: 1992
image: peliculas/pelicula_10.jpg
---

El filme comienza con el intento de Jafar, Gran Visir del Sultán de la ficticia ciudad de Agrabah, de acceder a la Cueva de las Maravillas, 
ya que en su interior hay una lámpara de aceite que contiene un genio. No obstante, este y su loro Iago necesitan de Aladdín para poder entrar 
en la cueva. A la par de esta situación, Jasmín, hija del Sultán, huye del palacio debido a que discrepa con su obligación de casarse. 
Es allí donde se encuentra con el niño callejero, Aladdín, y su mono Abu, pero ambos son capturados por el visir.

No obstante, Jafar decide liberarlos porque les necesita para entrar en la Cueva de las Maravillas. Cuando llegan allí, se encuentran con una 
alfombra mágica y posteriormente descubren la lámpara, hasta que la cueva empieza a colapsar tras el intento de Abu de robar una joya. En ese momento, 
Jafar intenta coger el candil, pero el mono acaba robándosela. Es así que Aladdín, Abu y la alfombra no consiguen escapar, cuando el protagonista 
inconscientemente frota la lámpara y aparece el Genio, que está dispuesto a concederle tres deseos, aunque consigue engañarle para que les saque del 
lugar sin gastar ninguno. Tras salir, le promete que uno será para liberarle, pero mientras tanto pide que le convierta en un príncipe para intentar que 
Jasmín se fije en él.