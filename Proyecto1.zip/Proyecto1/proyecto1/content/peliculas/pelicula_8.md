---
id: pelicula_8
name: El Gato con Botas
directorId: director_4
estudioId: estudio_2
gender: Aventura
duration: 90 minutos 
year: 2011
image: peliculas/pelicula_8.jpg
---

Gato es un fugitivo de la justicia que se dedica a cometer robos para subsistir, sin robar a personas de bajos recursos o a iglesias. 
El personaje se asemeja en su actitud de forajido al personaje ficticio El Zorro quien curiosamente también es interpretado por Antonio Banderas, 
la voz de Gato.

El lugar en el que fue criado Gato es en el pueblo de San Ricardo, donde fue abandonado de pequeño en un orfanato. Allí conoce a la mujer a quien él 
llamaría Madre y a su único amigo y hermano, un huevo llamado Humpty Alexander Dumpty (Zach Galifianakis). Junto a Humpty planean encontrar los frijoles 
mágicos que, según Humpty, despiertan una inmensa planta que conduce a una tierra mágica en el cielo.

Ambos se dedican a robar frijoles a varios pueblerinos para encontrar los mágicos. Poco a poco entran en una relación de delincuentes que su madre no 
aprueba y de la cual les intenta disuadir. Sin embargo, Gato y Humpty continúan con su tarea de ladrones. Tiempo después, Humpty ve amenazado su sueño 
cuando Gato logra salvar a la madre del comandante de morir embestida por un toro. Desde allí el pueblo de San Ricardo homenajea a Gato y le otorga, 
como símbolo de honor y justicia, sus botas. Este suceso abre los ojos de Gato, quien decide que no robaría más a nadie, aunque fuera un frijol, y que 
él pertenecía al pueblo donde había crecido junto con su Madre y su hermano Humpty.