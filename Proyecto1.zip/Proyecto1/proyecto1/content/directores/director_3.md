---
id: director_3
name: Brad Bird
nationality: Estadounidense
birth_year: 24 de septiembre de 1957
peliculaId: pelicula_3
image: directores/director_3.jpg
---

Bird fue contratado en 1989 por Klasky Csupo y ayudó a desarrollar Los Simpson a partir de historias de un minuto de El show de Tracey Ullman y a 
transformarlas en una serie de media hora de duración. Allí trabajó algunos años más como consultor ejecutivo. Posteriormente trabajó en otras series animadas, 
entre ellas El crítico, King of the Hill y Family Dog, antes de ser contratado por Warner Bros. para dirigir la película animada El gigante de hierro. 
Aunque la película recibió buenas críticas, no tuvo tan buenos resultados en taquilla, debido a la nula promoción de la propia Warner. Bird fue finalmente 
contratado por Lasseter para dirigir Los Increíbles.

Bird es también el creador (guionista, director y coproductor) del episodio "Family Dog" de la serie Amazing Stories, de Steven Spielberg. 
Además, coescribió el guion para la película de acción real Batteries Not Included, también producida por Spielberg.

En 2005, ganó el Óscar en la categoría a la Mejor Película de Animación por Los Increíbles y en 2007 por Ratatouille.

En 2011, durante la ceremonia de los premios Annie, recibió el Premio Winsor McCay como reconocimiento a su carrera.