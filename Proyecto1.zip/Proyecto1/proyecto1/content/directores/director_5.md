---
id: director_5
name: Simon J. Smith
nationality: Estadounidense
birth_year: 8 de septiembre de 1968
peliculaId: pelicula_1
image: directores/director_5.jpg
---

Es un cineasta estadounidense, egresado del Instituto de las Artes de California.1​2​ Es conocido por ser el director de El rey león, 
película animada ganadora de dos premios Óscar.