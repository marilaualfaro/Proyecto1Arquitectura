---
id: director_6
name: Roger Allers
nationality: Estadounidense
birth_year: 29 de junio de 1949 
peliculaId: pelicula_2
image: directores/director_6.jpg
---

En octubre de 1991, Allers fue contratado para codirigir El rey de la jungla junto con George Scribner. Allers invitó a Brenda Chapman, 
quien se convertiría en jefa de guionistas, a que se uniese al proyecto. Poco tiempo después, varios miembros del equipo, incluyendo a Allers, 
Scribner, Don Hahn, Chapman y el productor Chris Sanders hicieron un viaje de safari al Parque nacional Hell's Gate, en Kenia, para estudiar y apreciar 
el entorno para la película. Después de seis meses de trabajo, Scribner decidió abandonar el proyecto, tras discutir con Allers y los productores por su 
decisión de convertir la película en un musical, ya que la intención de Scribner era hacer una película de tipo documental, más centrada en la naturaleza.
4​ Luego de la partida de Scribner, Allers, Hahn, Sanders, Chapman y los directores de La bella y la bestia Kirk Wise y Gary Trousdale decidieron descartar 
la idea original y concibieron una nueva historia para la película en dos días, en febrero de 1992.5​ En abril de 1992, Allers formó un equipo con Rob Minkoff, 
quien fue seleccionado como codirector,1​ y el título de la película fue cambiado a El rey león.