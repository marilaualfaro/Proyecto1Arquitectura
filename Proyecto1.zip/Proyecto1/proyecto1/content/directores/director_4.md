---
id: director_4
name: Andrew Ralph Adamson
nationality: Nueva Zelanda
birth_year: 1 de diciembre de 1966
peliculaId: pelicula_4
image: directores/director_4.jpg
---

Adamson quería ser arquitecto, pero pasó la fecha límite de inscripción en esa carrera debido a un accidente de tráfico. Andrew fue contratado 
por Pacific Data Images para ir a trabajar a los Estados Unidos. La compañía abrió una oficina en la californiana ciudad de Los Ángeles. 
Allí sirvió como director técnico en películas como Toys (1992) protagonizada por Robin Williams o Angels in the Outfield (1994) en la que 
aparece Danny Glover. Adamson se especializó en la realización de anuncios comerciales pero pronto prefirió la idea de contar historias de mayor duración. 
Andrew sirvió de supervisor de efectos visuales en Batman Forever, A Time to Kill (1996) y Batman y Robin (1997).

