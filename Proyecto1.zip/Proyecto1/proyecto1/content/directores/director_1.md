---
id: director_1
name: Tom McGrath
nationality: Estadounidense
birth_year: 7 de agosto de 1964
peliculaId: pelicula_1
image: directores/director_1.jpg
---

Tom McGrath es un animador, actor de voz y productor estadounidense. Actualmente es la voz de Skipper en Madagascar, y también es el creador de la serie 
Los pingüinos de Madagascar. En 2005, co-dirigió la famosa película Madagascar de DreamWorks con Eric Darnell y también su secuela, Madagascar 2.

