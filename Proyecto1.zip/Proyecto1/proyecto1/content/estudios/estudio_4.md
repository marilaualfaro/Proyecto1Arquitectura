---
id: estudio_4
name: Sony Pictures Animation
country: Estados Unidos
peliculaId: pelicula_12
image: estudios/estudio_4.jpg
---

En 2001, Sony Pictures Entertainment considera la venta de su planta de efectos visuales Sony Pictures Imageworks (SPI), 
después de no poder encontrar un comprador adecuado, y de haber quedado impresionado con las imágenes creadas en Stuart Little 2 , 
y viendo el éxito de taquilla de Shrek y Monsters Inc. , Sony Pictures Imageworks fue mejorada para convertirse en un estudio de animación. 
Astro Boy, que tuvo desarrollo en Sony desde 1997 como película de acción en vivo, iba a ser la primera de este estudio hecha totalmente por 
gráficos de computadora.2​En mayo de 2002, Sony Pictures Animation se creó para desarrollar personajes, historias y películas, con SPI haciéndose 
cargo de la producción digital,3​ manteniendo su producción de efectos visuales.4​

Su primer largometraje Open Season fue lanzado el 29 de septiembre de 2006. La película de mayor éxito financiero hasta la fecha es Los Pitufos. 
La película del estudio que ganó el Oscar a la categoría a Mejor película animada es Spider-Man: Un nuevo universo en 2018. Y el último largometraje 
que fue lanzado por el estudio es Vivo en 2021.

Sony Pictures Animation está trabajando actualmente en Spider-Man: Un Nuevo Universo 2 (2022) y Hotel Transylvania 4 (2021).