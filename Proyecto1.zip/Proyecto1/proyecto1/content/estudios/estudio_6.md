---
id: estudio_6
name: Laika, LLC.
country: Estados Unidos
peliculaId: pelicula_10
image: estudios/estudio_6.jpg
---

A finales de 1990, Will Vinton Studios, conocido por sus anuncios y sus películas stop-motion, buscó fondos para producir 
más películas cinematográficas y compró inversores externos, entre los que se incluían Phil Knight, el propietario de Nike. 
En 1998, Knight hizo su inversión inicial y su hijo Travis comenzó a trabajar en el estudio como animador. En 2002, Phil Knight 
adquirió financieramente Will Vinton Studios para realizar producciones cinematográficas.4​ El año siguiente, Henry Selick , 
director de El Extraño Mundo de Jack, se unió al estudio como director supervisor.5​ En julio de 2005, Will Vintion Studios desapareció 
y fue sustituido por Laika, que se dividió en dos departamentos: Laika Entertainment para la producción de largometrajes y Laika/house 
para la producción comercial (como anuncios publicitarios y vídeos musicales). También anunciaron sus primeros proyectos: una película de 
stop-motion llamada Coraline y la película de animación de CGI Jack & Ben's Animated Adventure.