---
id: estudio_1
name: DreamWorks Animation LLC
country: Estados Unidos
peliculaId: pelicula_1
image: estudios/estudio_1.jpg
---

DreamWorks Animation SKG, Inc. es un estudio de animación estadounidense filial de Universal Pictures, una subsidaria de NBCUniversal, 
que es propiedad total de Comcast, que produce principalmente películas y series animadas por ordenador.

Se formó originalmente bajo el nombre de DreamWorks Pictures en 1994 por miembros de Amblin Entertainment. 
Se convirtió en una empresa independiente en 2004. DreamWorks Animation mantiene su sede en Glendale, California, así como también posee estudios 
en la India y China. El 22 de agosto de 2016, NBCUniversal adquirió DreamWorks Animation por $3.8 mil millones de dólares, convirtiéndose en una división 
de Universal Filmed Entertainment Group así como una propiedad total de Comcast.

Entre los éxitos más famosos que ha producido la compañía se encuentran: Shrek, El espantatiburones, Madagascar, 2 y 3, Los pingüinos de Madagascar 
(Película y serie), Bee Movie, Kung Fu Panda y su serie, Spirit el corcel indomable, Monsters vs Aliens, Cómo entrenar a tu dragón, 2 y 3, y su serie, 
Megamind, El Príncipe de Egipto, El origen de los guardianes, Los Croods, Trolls, The Boss Baby, Turbo (serie 2D), HOME, Las aventuras de Peabody y Sherman 
y Captain Underpants.