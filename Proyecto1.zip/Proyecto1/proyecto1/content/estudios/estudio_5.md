---
id: estudio_5
name: Warner Bros. Animation
country: Estados Unidos
peliculaId: pelicula_11
image: estudios/estudio_5.jpg
---

Hugh Harman y Rudolf Ising crearon las series Looney Tunes y Merrie Melodies en 1930 y 1931, respectivamente. 
Ambas fueron producidas por Leon Schlesigner en el estudio Harman e Ising en Hollywood, los cortometrajes eran 
distribuidos por Warner Bros. Pictures. La primera estrella de Looney Tunes fue Bosko. En 1933, Harman e Ising se 
separaron de Schlesigner debido a disputas financieras,1​ y Schlesinger crea su propio estudio en Sunset Boulevard, Hollywood.

El estudio de Schlesinger tuvo un comienzo lento, continuó haciendo la serie Merrie Melodies e introdujo un reemplazo de Bosko, Buddy. 
El veterano de Disney Jack King, fue el primer director del estudio; otros directores de Warner incluyen Earl Duvall, Bernard Brown, 
y el alumno de Harman e Ising Isadore "Friz" Freleng.​ En 1935, Freleng dirigió el cortometraje de Merrie Melodies I Haven't Got a Hat, 
primera aparición de Porky.4​ Duvall se fue del estudio, y fue reemplazado por Fred "Tex" Avery, quien utilizó a Porky en varios dibujos 
animados, convirtiéndolo en la nueva estrella del estudio.